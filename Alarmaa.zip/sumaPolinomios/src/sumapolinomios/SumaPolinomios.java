
package sumapolinomios;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.*;
import static java.lang.Math.min;


public class SumaPolinomios {

    public static void main(String[] args) {
        int n, m, x;
        Scanner sc = new Scanner(System.in);

        System.out.print("Inserta el grado del primer polinomio: ");
        n = sc.nextInt();
        n++;

        System.out.print("Inserta el grado del segundo polinomio: ");
        m = sc.nextInt();
        m++;

        System.out.println();

        ArrayList<Integer> A = new ArrayList<>();
        ArrayList<Integer> B = new ArrayList<>();

        //A = [a,b,c,d,e] = a + bx + cx^2 + dx^3 + ex^4...
        //B = [f,g,h] = f + gx + hx^2
        //SUM = [a+f, b+g, c+h, d, e]
        for (int i = 0; i < n; i++){
            System.out.print("Inserta el coeficiente número " + i + " del primer polinomio: ");
            x = sc.nextInt();
            A.add(x);
        }

        System.out.println();

        for (int i = 0; i < m; i++){
            System.out.print("Inserta el coeficiente número " + i + " del segundo polinomio: ");
            x = sc.nextInt();
            B.add(x);
        }

        System.out.println();

        ArrayList<Integer> sum = new ArrayList<>();
        if (n >= m){
            for (int i = 0; i < n; i++){
                sum.add(A.get(i));
            }
        }else{
            for (int i = 0; i < m; i++){
                sum.add(B.get(i));
            }
        }

        for (int i = 0; i < min(n,m); i++){
            sum.set(i, A.get(i) + B.get(i));
        }

        System.out.print("Los coeficientes del polinomio final son: ");
        for (int e : sum){
            System.out.print(e + " ");
        }
        System.out.println();
    }
}
